package com.pvgr.downloader;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.app.DownloadManager;
import android.database.Cursor;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(7,16,21), PANEL = Color.rgb(17,29,35);
    private final int CYAN = Color.rgb(28,198,216), MUTED = Color.rgb(145,163,171);
    private DownloadManager dm;
    private LinearLayout root, body, nav;
    private String page = "Home";
    private int simultaneous = 3;
    private boolean wifiOnly = false;
    private String theme = "Dark";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        dm = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        showPage("Home");
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 10);
    }

    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(2, stroke); return d;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private void pad(View v, int a) { v.setPadding(a,a,a,a); }
    private TextView button(String text) {
        TextView v = label(text, 15, Color.WHITE, true); v.setGravity(Gravity.CENTER);
        v.setPadding(18,15,18,15); v.setBackground(shape(CYAN,28,0)); v.setTextColor(BG); return v;
    }
    private void showPage(String p) {
        page=p;
        root=column(); root.setBackgroundColor(BG);
        ScrollView scroll=new ScrollView(this);
        body=column(); body.setPadding(22,28,22,24);
        scroll.addView(body);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=row(); nav.setBackgroundColor(PANEL); nav.setPadding(8,8,8,8);
        String[] tabs={"⌂  Home","⇩  Downloads","⚙  Settings"};
        for(String tab:tabs) {
            final String name=tab.contains("Home")?"Home":tab.contains("Downloads")?"Downloads":"Settings";
            TextView t=label(tab,14,name.equals(page)?CYAN:MUTED,true); t.setGravity(Gravity.CENTER);
            t.setPadding(5,18,5,18); nav.addView(t,new LinearLayout.LayoutParams(0,-2,1));
            t.setOnClickListener(v->showPage(name));
        }
        root.addView(nav); setContentView(root);
        if(p.equals("Home")) home(); else if(p.equals("Downloads")) downloads(); else settings();
    }
    private void heading(String title,String sub) {
        body.addView(label(title,30,Color.WHITE,true));
        TextView s=label(sub,15,MUTED,false); s.setPadding(0,5,0,22); body.addView(s);
    }
    private void home() {
        heading("PVGR DOWNLOADER","Fast. Simple. In your control.");
        TextView status=label("YOUR DOWNLOADS",12,CYAN,true); body.addView(status);
        LinearLayout card=column(); card.setPadding(18,18,18,18); card.setBackground(shape(PANEL,28,Color.rgb(35,55,63)));
        card.addView(label("Ready when you are",21,Color.WHITE,true));
        card.addView(label("Paste a direct file URL to begin downloading.",14,MUTED,false));
        TextView add=button("＋   Add download"); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.topMargin=20;
        card.addView(add,bp); add.setOnClickListener(v->addDownloadDialog());
        body.addView(card);
        TextView recent=label("Recent downloads",21,Color.WHITE,true); recent.setPadding(0,28,0,12); body.addView(recent);
        addRecentItems();
    }
    private void addDownloadDialog() {
        EditText input=new EditText(this); input.setSingleLine(true); input.setTextColor(Color.WHITE);
        input.setHintTextColor(MUTED); input.setHint("https://example.com/file.zip");
        input.setPadding(24,12,24,12); input.setBackground(shape(PANEL,18,Color.rgb(45,65,73)));
        new AlertDialog.Builder(this).setTitle("Add download").setMessage("Enter a direct file URL")
            .setView(input).setNegativeButton("Cancel",null).setPositiveButton("Download",(d,w)->{
                String url=input.getText().toString().trim();
                if (!(url.startsWith("https://") || url.startsWith("http://"))) {
                    Toast.makeText(this,"Please enter a valid http/https URL",Toast.LENGTH_LONG).show(); return;
                }
                try {
                    DownloadManager.Request req=new DownloadManager.Request(Uri.parse(url));
                    String name=Uri.parse(url).getLastPathSegment();
                    if(name==null || name.trim().isEmpty()) name="pvgr_download_"+System.currentTimeMillis();
                    req.setTitle(name); req.setDescription("Downloading with PVGR DOWNLOADER");
                    req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"PVGR/"+name);
                    if(wifiOnly) req.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
                    dm.enqueue(req);
                    Toast.makeText(this,"Download added",Toast.LENGTH_SHORT).show();
                    showPage("Home");
                } catch(Exception e) { Toast.makeText(this,"Could not start download: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
            }).show();
    }
    private void addRecentItems() {
        Cursor c=dm.query(new DownloadManager.Query().setFilterByStatus(DownloadManager.STATUS_RUNNING |
            DownloadManager.STATUS_PENDING | DownloadManager.STATUS_PAUSED | DownloadManager.STATUS_SUCCESSFUL |
            DownloadManager.STATUS_FAILED));
        int count=0;
        if(c!=null) {
            while(c.moveToNext() && count<8) {
                String name=c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                int status=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                long total=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                long done=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                String state=status==DownloadManager.STATUS_SUCCESSFUL?"Completed":
                    status==DownloadManager.STATUS_FAILED?"Failed":status==DownloadManager.STATUS_PAUSED?"Paused":"Downloading";
                addDownloadCard(name,state,done,total); count++;
            }
            c.close();
        }
        if(count==0) body.addView(label("No downloads yet. Your files will appear here.",14,MUTED,false));
    }
    private void addDownloadCard(String name,String state,long done,long total) {
        LinearLayout card=column(); card.setPadding(16,15,16,15); card.setBackground(shape(PANEL,22,0));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.topMargin=9; body.addView(card,cp);
        card.addView(label(name==null?"Download":name,16,Color.WHITE,true));
        TextView st=label(state+"  •  "+(total>0?String.format(Locale.US,"%.1f / %.1f MB",done/1048576f,total/1048576f):"Size unknown"),13,CYAN,false);
        st.setPadding(0,7,0,7); card.addView(st);
        ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); progress.setProgress(total>0?(int)(done*100/total):0); card.addView(progress,new LinearLayout.LayoutParams(-1,8));
    }
    private void downloads() {
        heading("Downloads","Manage your files and download activity.");
        LinearLayout filters=row();
        for(String f:new String[]{"All","Active","Paused","Completed"}) {
            TextView t=label(f,13,CYAN,true); t.setPadding(10,10,10,10); filters.addView(t);
            t.setOnClickListener(v->showPage("Downloads"));
        }
        body.addView(filters); addRecentItems();
    }
    private void settings() {
        heading("Settings","Make PVGR DOWNLOADER work your way.");
        settingTitle("Appearance");
        settingRow("Theme","Dark AMOLED interface");
        settingTitle("Downloads");
        settingRow("Downloads at the same time","Maximum queue preference: "+simultaneous);
        TextView count=button("Change: 1   /   2   /   3"); body.addView(count);
        count.setOnClickListener(v->{String[] a={"1","2","3"}; new AlertDialog.Builder(this).setTitle("Simultaneous downloads")
            .setItems(a,(d,w)->{simultaneous=w+1;showPage("Settings");}).show();});
        settingRow("Wi-Fi only",wifiOnly?"Enabled":"Disabled");
        TextView wifi=button(wifiOnly?"Turn off Wi-Fi only":"Turn on Wi-Fi only"); body.addView(wifi);
        wifi.setOnClickListener(v->{wifiOnly=!wifiOnly;showPage("Settings");});
        settingTitle("Storage");
        settingRow("Save location","Downloads/PVGR");
        settingTitle("About");
        settingRow("Version","1.0 • PVGR DOWNLOADER");
    }
    private void settingTitle(String s) { TextView t=label(s,20,Color.WHITE,true); t.setPadding(0,24,0,12); body.addView(t); }
    private void settingRow(String title,String sub) {
        LinearLayout c=column(); c.setPadding(16,15,16,15); c.setBackground(shape(PANEL,18,0));
        c.addView(label(title,16,Color.WHITE,true)); c.addView(label(sub,13,MUTED,false));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=8; body.addView(c,lp);
    }
}
