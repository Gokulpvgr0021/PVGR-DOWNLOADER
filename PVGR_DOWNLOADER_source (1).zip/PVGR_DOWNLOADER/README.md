# PVGR DOWNLOADER

A native Android starter project inspired by the supplied EDM screenshots.

## Included
- Premium dark AMOLED / cyan interface
- Home, Downloads and Settings tabs
- Add direct HTTP/HTTPS file URL
- Android system DownloadManager integration
- Download notifications and progress/history query
- Wi-Fi-only preference and download concurrency preference UI
- Files saved under `Downloads/PVGR/`

## Build an APK
Open this folder in Android Studio, allow Gradle sync, then choose:
**Build > Build Bundle(s) / APK(s) > Build APK(s)**

The APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Important MVP limitations
Android's public `DownloadManager` API does not expose reliable per-download pause/resume or a way to set the number of parallel connections per file. The concurrency setting is currently a preference UI, not an enforced scheduler. Those features need a custom foreground download service and a range-capable HTTP engine. This starter does not bypass website protections or download DRM-protected/streaming media; use direct URLs for files you are authorized to download.
